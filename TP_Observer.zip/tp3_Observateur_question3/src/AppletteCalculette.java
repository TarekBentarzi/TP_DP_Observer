
import java.awt.GridLayout;

import javax.swing.JApplet;
import javax.swing.JRootPane;

/**
 * Classe Applette - d�crivez la classe ici
 *
 * @author: (votre nom)
 * @version: (un num�ro de version ou une date)
 */
public class AppletteCalculette extends JApplet {

	/**
	 *
	 */
	private static final long serialVersionUID = -1989253833727373654L;

	public void init() {
		JRootPane rootPane = this.getRootPane();
		rootPane.putClientProperty("defeatSystemEventQueueCheck", Boolean.TRUE);

		PileModele<Integer> modele = new PileModele<Integer>(new Pile2<Integer>(5));
		Controleur controle = new Controleur(modele);
		Vue vue = new Vue(modele);
		Vue2 vue2= new Vue2(modele);
		setLayout(new GridLayout(2, 1));
		add(vue);
		add(vue2);
		add(controle);
		setVisible(true);

	}

}
