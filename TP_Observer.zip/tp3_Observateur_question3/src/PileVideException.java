

/**
 * D�crivez votre classe PilePleineException ici.
 *
 * @author (votre nom)
 * @version (un num�ro de version ou une date)
 */
public class PileVideException extends Exception {

    public PileVideException() {
        super();
    }

    public PileVideException(String message) {
        super(message);
    }

}