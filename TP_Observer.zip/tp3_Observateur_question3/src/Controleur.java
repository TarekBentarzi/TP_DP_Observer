

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * D�crivez votre classe Controleur ici.
 *
 * @author (votre nom)
 * @version (un num�ro de version ou une date)
 */
public class Controleur extends JPanel implements ActionListener{

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private JButton push, add, sub, mul, div, clear;
	private PileModele<Integer> pile;
	private JTextField donnee;

	public Controleur(PileModele<Integer> pile) {
		super();
		this.pile = pile;
		this.donnee = new JTextField(8);

		this.push = new JButton("push");
		this.add = new JButton("+");
		this.sub = new JButton("-");
		this.mul = new JButton("*");
		this.div = new JButton("/");
		this.clear = new JButton("[]");

		setLayout(new GridLayout(2, 1));
		add(donnee);
		donnee.addActionListener(this);
		JPanel boutons = new JPanel();
		boutons.setLayout(new FlowLayout());
		boutons.add(push);  push.addActionListener(this);
		boutons.add(add);   add.addActionListener(this);
		boutons.add(sub);   sub.addActionListener(this);
		boutons.add(mul);   mul.addActionListener(this);
		boutons.add(div);   div.addActionListener(this);
		boutons.add(clear); clear.addActionListener(this);
		add(boutons);
		boutons.setBackground(Color.red);
		actualiserInterface();
	}

	public void actualiserInterface() {

		// � compl�ter
	}

	private Integer operande() throws NumberFormatException {
		return Integer.parseInt(donnee.getText());
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		if(arg0.getActionCommand().equals("push")) {
			try {
				pile.empiler(operande());
			} catch (NumberFormatException | PilePleineException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if(arg0.getActionCommand().equals("+")) {
			try {
				pile.empiler(pile.depiler()+pile.depiler());
			} catch (PilePleineException | PileVideException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}else if(arg0.getActionCommand().equals("-")) {
			try {
				pile.empiler(pile.depiler()-pile.depiler());
			} catch (PilePleineException | PileVideException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if(arg0.getActionCommand().equals("*")) {
			try {
				pile.empiler(pile.depiler()*pile.depiler());
			} catch (PilePleineException | PileVideException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if(arg0.getActionCommand().equals("/")){
			try {
				pile.empiler(pile.depiler()/pile.depiler());
			} catch (PilePleineException | PileVideException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if(arg0.getActionCommand().equals("[]")){
                  //pile.toString();
		}
	}



	// � compl�ter
	// en cas d'exception comme division par z�ro, mauvais format de nombre
	// la pile reste en l'�tat (intacte)

}
