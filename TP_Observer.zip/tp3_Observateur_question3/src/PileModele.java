

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observable;

import com.sun.org.apache.xalan.internal.xsltc.compiler.sym;

public class PileModele<T> extends Observable implements PileI<T> {

	private PileI<T> pile;
	/* � compl�ter */

	public PileModele(PileI<T> pile) {
		this.pile = pile;
	}

	public void empiler(T o) throws PilePleineException {
		pile.empiler(o);
		setChanged();
		notifyObservers();
	}

	public T depiler() throws PileVideException {
		setChanged();
		notifyObservers();
		return pile.depiler();
	}

	public T sommet() throws PileVideException {
		setChanged();
		notifyObservers();
		return pile.sommet();
	}

	public int taille() {
		return pile.taille();
	}

	public int capacite() {
		return pile.capacite();
	}

	public boolean estVide() {
		return pile.estVide();
	}

	public boolean estPleine() {
		return pile.estPleine();
	}

	public String toString() {
//		setChanged();
//		notifyObservers();
		return pile.toString();
	}

}

/**
 * notez qu'un message d'alerte subsiste � la compilation (unsafe ...) d� �
 * l'emploi de notifyObservers, incontournable et sans cons�quence ici
 */
