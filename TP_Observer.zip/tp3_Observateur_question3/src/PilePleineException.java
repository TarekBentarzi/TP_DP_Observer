
/**
 * D�crivez votre classe PilePleineException ici.
 *
 * @author (votre nom)
 * @version (un num�ro de version ou une date)
 */
public class PilePleineException extends Exception {

	public PilePleineException() {
		super();
	}

	public PilePleineException(String message) {
		super(message);
	}

}